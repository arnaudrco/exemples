var searchData=
[
  ['il9163_5f128x128_5finit',['il9163_128x128_init',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gaab951faf7291d6c038296863c3d3b05b',1,'lcd_il9163.c']]],
  ['il9163_5f128x128_5fspi_5finit',['il9163_128x128_spi_init',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gaf487eab5aee04c6ce2eca11833992132',1,'lcd_il9163.c']]],
  ['il9163_5fsetmode',['il9163_setMode',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gaa85db34b703ff8b54d86a8eea5b30bab',1,'il9163_setMode(lcd_mode_t mode):&#160;lcd_il9163.c'],['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gaa85db34b703ff8b54d86a8eea5b30bab',1,'il9163_setMode(lcd_mode_t mode):&#160;lcd_il9163.c']]],
  ['il9163_5fsetoffset',['il9163_setOffset',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#ga10928d9f89617a3b92731f001283709b',1,'lcd_il9163.c']]],
  ['il9163_5fsetrotation',['il9163_setRotation',['../group___i_l9163___s_t7734___a_p_i.html#ga9810641c687840a775089f19449499c6',1,'il9163_setRotation(uint8_t rotation):&#160;lcd_il9163.c'],['../group___i_l9163___s_t7734___a_p_i.html#ga9810641c687840a775089f19449499c6',1,'il9163_setRotation(uint8_t rotation):&#160;lcd_il9163.c']]],
  ['ili9341_5f240x320_5finit',['ili9341_240x320_init',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#ga02c6aa375576491c9d1574f7b6250ff9',1,'lcd_ili9341.c']]],
  ['ili9341_5f240x320_5fspi_5finit',['ili9341_240x320_spi_init',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#ga4ec1ef49596fac230a5652b3497dde14',1,'lcd_ili9341.c']]],
  ['ili9341_5frotateoutput',['ili9341_rotateOutput',['../group__ili9341___a_p_i.html#gaca229dbd2360874b65ff481306f2a515',1,'ili9341_rotateOutput(uint8_t on):&#160;lcd_ili9341.c'],['../group__ili9341___a_p_i.html#gaca229dbd2360874b65ff481306f2a515',1,'ili9341_rotateOutput(uint8_t on):&#160;lcd_ili9341.c']]],
  ['ili9341_5fsetmode',['ili9341_setMode',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gac338746c1f4c80298ec9cd4d70c3a151',1,'ili9341_setMode(lcd_mode_t mode):&#160;lcd_ili9341.c'],['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gac338746c1f4c80298ec9cd4d70c3a151',1,'ili9341_setMode(lcd_mode_t mode):&#160;lcd_ili9341.c']]],
  ['ili9341_5fsetrotation',['ili9341_setRotation',['../group__ili9341___a_p_i.html#gae8f7db8265a495262906ac9704853347',1,'ili9341_setRotation(uint8_t rotation):&#160;lcd_ili9341.c'],['../group__ili9341___a_p_i.html#gae8f7db8265a495262906ac9704853347',1,'ili9341_setRotation(uint8_t rotation):&#160;lcd_ili9341.c']]],
  ['invert',['invert',['../class_nano_canvas.html#ae25cac1c7da55ee6df1e75275b92e626',1,'NanoCanvas']]],
  ['isnearmove',['isNearMove',['../struct_s_p_r_i_t_e.html#a20017763966ef3adcf3bb7015e39eb14',1,'SPRITE']]]
];
