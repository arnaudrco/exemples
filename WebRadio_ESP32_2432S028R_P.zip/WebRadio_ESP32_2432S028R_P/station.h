//========================================================================
int un = 78-1;     // Change depending on the number of URLs
char *url[78] = {  // url*Station name
  "https://stream.radiofrance.fr/monpetitfranceinter/monpetitfranceinter.m3u8*Petit France Inter", // OK   "https://radio-stream.nhk.jp/hls/live/2023229/nhkradiruakr1/master.m3u8*NHK Tokyo 1", // OK
  "https://radio-stream.nhk.jp/hls/live/2023501/nhkradiruakr2/master.m3u8*NHK Tokyo 2", // OK
  "https://radio-stream.nhk.jp/hls/live/2023507/nhkradiruakfm/master.m3u8*NHK Tokyo FM", // OK
  "https://radio-stream.nhk.jp/hls/live/2023545/nhkradiruikr1/master.m3u8*NHK Saporo 1", // OK
  "https://radio-stream.nhk.jp/hls/live/2023546/nhkradiruikfm/master.m3u8*NHK Saporo FM", // OK
  "https://radio-stream.nhk.jp/hls/live/2023543/nhkradiruhkr1/master.m3u8*NHK Sendai 1", // OK
  "https://radio-stream.nhk.jp/hls/live/2023544/nhkradiruhkfm/master.m3u8*NHK Sendai FM", // OK
  "https://radio-stream.nhk.jp/hls/live/2023510/nhkradiruckr1/master.m3u8*NHK Nagoya 1", // OK
  "https://radio-stream.nhk.jp/hls/live/2023511/nhkradiruckfm/master.m3u8*NHK Nagoya FM", // OK
  "https://radio-stream.nhk.jp/hls/live/2023508/nhkradirubkr1/master.m3u8*NHK Osaka 1", // OK
  "https://radio-stream.nhk.jp/hls/live/2023509/nhkradirubkfm/master.m3u8*NHK Osaka FM", // OK
  "https://radio-stream.nhk.jp/hls/live/2023512/nhkradirufkr1/master.m3u8*NHK Hiroshima 1", // OK
  "https://radio-stream.nhk.jp/hls/live/2023513/nhkradirufkfm/master.m3u8*NHK Hiroshima FM", // OK
  "https://radio-stream.nhk.jp/hls/live/2023547/nhkradiruzkr1/master.m3u8*NHK Matuyama 1", // OK
  "https://radio-stream.nhk.jp/hls/live/2023548/nhkradiruzkfm/master.m3u8*NHK Matuyama FM", // OK
  "https://radio-stream.nhk.jp/hls/live/2023541/nhkradirulkr1/master.m3u8*NHK Fukuoka 1", // OK
  "https://radio-stream.nhk.jp/hls/live/2023542/nhkradirulkfm/master.m3u8*NHK Fukuoka FM", // OK
  "http://radio.kahoku.net:8000/;?type=http&nocache=652*FMkahoku", // OK

  "https://ottava2.out.airtime.pro:8000/ottava2_a*Ottava", // OK
  "https://c13.radioboss.fm:8200/stream*WREP Live", // OK
  "http://208.115.220.38:8073/*Radio Hayama", // OK
  "https://relay0.r-a-d.io/main.mp3*r-a-d-io", // OK
  "http://centova.svdns.com.br:25286/*RCV FM", // OK
  "https://radicrojapan.out.airtime.pro/radicrojapan_a*RadiCro", // OK
  "https://radio.garden/api/ara/content/listen/pZRZwukg/channel.mp3*Nonstop Casiopea", // OK
  "https://streaming.radio.co/se4a8e6a93/listen*Hitsujikai Radio", // OK
  "https://radio.garden/api/ara/content/listen/xows1EuO/channel.mp3*Tannan FM 79.1", // OK
  "https://sv10.hdradios.net:21920/*Radio Shiga", // OK
  "https://streaming.exclusive.radio/er/abba/icecast.audio*ABBA", // OK
  "https://nl4.mystreaming.net/er/depechemode/icecast.audio*Depeche Mode", // OK
  "https://streaming.exclusive.radio/er/garymoore/icecast.audio*Gary Moore", // OK
  "https://nl4.mystreaming.net/er/annielennox/icecast.audio*Annie Lennox", // OK
  "http://wbgo.streamguys.net/thejazzstream*jazzstream", // OK
  "http://ais-sa2.cdnstream1.com/b22139_128mp3*101 SMOOTH JAZZ", // Sound cuts out
  "http://listen.181fm.com/181-beatles_128k.mp3*181-beatles_128k", // Sound cuts out
  "http://s1.knixx.fm/dein_webradio_64.aac*webradio 64 aac", // OK aac

//  *** radio streams *** 11
//"http://stream.antennethueringen.de/live/aac-64/stream.antennethueringen.de/*aac",     // aac // Receives but no sound
//"http://mcrscast.mcr.iol.pt/cidadefm*mp3",                                             // mp3 // Receives but no sound
  "http://www.wdr.de/wdrlive/media/einslive.m3u*einslive.m3u",                           // m3u // OK
  "https://stream.srg-ssr.ch/rsp/aacp_48.asx*aacp 48.asx",                               // asx // OK
  "http://tuner.classical102.com/listen.pls*listen.pls",                                 // pls // OK
//"http://stream.radioparadise.com/flac*flac",                                           // flac // Receives but no sound
//"http://stream.sing-sing-bis.org:8000/singsingFlac*flac (ogg)",                        // flac (ogg) // Receives but no sound
  "http://s1.knixx.fm:5347/dein_webradio_vbr.opus*dein opus (ogg)",                      // opus (ogg) // OK
  "http://stream2.dancewave.online:8080/dance.ogg*vorbis (ogg)",                         // vorbis (ogg) // Receives but no sound
//"http://26373.live.streamtheworld.com:3690/XHQQ_FMAAC/HLSTS/playlist.m3u8*HLS",        // HLS // Receives but no sound
//"http://eldoradolive02.akamaized.net/hls/live/2043453/eldorado/master.m3u8*HLS (ts)",  // HLS (ts) // Receives but no sound
//  *** web files *** 6
//"https://github.com/schreibfaul1/ESP32-audioI2S/raw/master/additional_info/Testfiles/Pink-Panther.wav*Pink-Panther wav",     // wav  // Receives but no sound
  "https://github.com/schreibfaul1/ESP32-audioI2S/raw/master/additional_info/Testfiles/Santiano-Wellerman.flac*flac",          // flac // OK
  "https://github.com/schreibfaul1/ESP32-audioI2S/raw/master/additional_info/Testfiles/Olsen-Banden.mp3*Olsen-Bandenmp3",      // mp3 // OK
//"https://github.com/schreibfaul1/ESP32-audioI2S/raw/master/additional_info/Testfiles/Miss-Marple.m4a*Miss-Marple m4a (aac)", // m4a (aac) // Receives but no sound
//"https://github.com/schreibfaul1/ESP32-audioI2S/raw/master/additional_info/Testfiles/Collide.ogg*vorbis",                    // vorbis // Receives but no sound
  "https://github.com/schreibfaul1/ESP32-audioI2S/raw/master/additional_info/Testfiles/sample.opus*sample opus",               // opus // OK

  "http://uk5.internet-radio.com:8174/stream*Joy Radio", // Sound cuts out
  "http://wbgo.streamguys.net/wbgo96*WBGO FM 96", // OK
  "http://play.global.audio/bgradio128*RADIO BGRADIO", // Sound cuts out
  "http://naxos.cdnstream.com:80/1255_128*Lite Favorites", // OK
  "http://stream.rockantenne.de/rockantenne/stream/mp3*rockantenne", // OK
  "http://wdr-wdr2-ruhrgebiet.icecast.wdr.de/wdr/wdr2/ruhrgebiet/mp3/128/stream.mp3*ruhrgebiet", // OK
  "http://www.ndr.de/resources/metadaten/audio/m3u/ndr2.m3u*ndr2", // Sound cuts out
  "http://vis.media-ice.musicradio.com/CapitalMP3*CapitalMP3", // OK
  "http://0n-80s.radionetz.de:8000/0n-70s.mp3*0n-70s", // OK
  "http://0n-80s.radionetz.de:8000/*radionetz", // OK
  "http://streams.br.de/bayern3_2.m3u*bayern3_2", // OK
  "http://play.antenne.de/antenne.m3u*antenne", // OK
  "http://streams.radiobob.de/bob-national/mp3-192/streams.radiobob.de/*streams.radiobob", // Sound cuts 
  "http://51.81.46.118:3340/;?type=http&nocache=567205/*J-Rock PowerPlay", // Sound cuts out
  "http://allstream.rainwave.cc:8000/all.mp3*Rainwave All", // OK
  "http://sc6.radiocaroline.net:8040/;?type=http&nocache=42646listen.pls*Radio Caroline", // OK ***
  "http://listen.181fm.com/181-chilled_128k.mp3*181 F M Chilled", // OK
  "http://ice2.somafm.com/christmas-128-mp3*SomaFM Xmas", // OK
  "http://188.138.9.183/lounge-austria-mobile.mp3*Unspecified name", // OK
  "http://listen2.myradio24.com:9000/8144*Radio Magic", // Sound cuts 
  "http://ais-edge16-jbmedia-nyc04.cdnstream.com/hot108*HOT 108 JAMZ", // OK
  "http://streams.iloveradio.de/iloveradio1.mp3*I Love Radio", // Sound cuts 
  "http://icy.unitedradio.it/VirginRogerWaters.mp3*PinkFloyd", // Sound cuts 
  "http://live.m2stream.fr/m280-128.mp3*M2 80's", // Sound cuts 
  "http://live.m2stream.fr/m2hit-128.mp3*M2 Hit's", // OK
  "http://live.m2stream.fr/m2club-128.mp3*M2 Club", // Sound cuts 
  "http://live.m2stream.fr/m2love-128.mp3*M2 Love", // Sound cuts
  "http://live.m2stream.fr/m2sunshine-128.mp3*M2 Sunshine", // Sound cuts
  "http://sc8.radiocaroline.net/;*Radio Caroline", // OK ***
  "http://us3.internet-radio.com:8496/stream?type=http&nocache=241*RaveRocksRadio", // OK
  "http://uk7.internet-radio.com:8168/stream?type=http&nocache=1226*242 RADIO stream", // OK
  "http://live.m2stream.fr/m2rock-128.mp3*M2 Rock", // OK

//"http://opera-stream.wqxr.org/wnycam-app*WNYC-AM - New York Public Radio", // Receives but no sound
//"http://uk5.internet-radio.com:8011/stream?type=http&nocache=158*Top 80 radio", // Receives but no sound
//"https://jenny.torontocast.com:2000/stream/J1HITS*J1 Radio", // Sound cuts out
//"https://jenny.torontocast.com:2000/stream/J1XTRA*J1 Radio Extra", // Sound cuts out
//"https://jenny.torontocast.com:2000/stream/J1GOLD*J1 Radio Gold", // Sound cuts out
//"https://listen.moe/fallback*Listen.moe", // Receives but no sound
//"http://n10.radiojar.com/66zgtscuc1duv*Radio Eigekai Indies", // Receives but no sound
//"http://n10.radiojar.com/66zgtscuc1duv?rj-ttl=5&rj-tok=AAABj2IAK0MABVE3BHz-7JkAHg*Radio Eigekai Indies", // Receives but no sound
//"https://s1-bos.liveatc.net/rjtt_app_dep*RJTT Tokyo Int - App/Dep", // Receives but no sound
//"https://s1-lhr.liveatc.net/rjtt_control*RJTT Tokyo Int - Control", // Receives but no sound
//"https://s1-bos.liveatc.net/rjtt_twr*RJTT Tokyo Int - Twr/TCA", // Receives but no sound
//"https://streamer.radio.co/s83eb8ff39/listen*Super Tokio Radio", // Receives but no sound
//"https://s1-fmt2.liveatc.net/rjoo1*RJOO Tower OSAKA", // Receives but no sound
//"https://shonanbeachfm.out.airtime.pro:8000/shonanbeachfm_a*Shonan Beach FM 78.9", // Receives but no sound // 湘南ビーチ
//"https://gotanno.love:8443/*Gotanno 89.2 ADATIKUMIN HOSOU", // Receives but no sound
//"http://gyusyabu.ddo.jp:8000/;stream.mp3*Gyusyabu - Retro PC Game Radio", // Receives but no sound
//"http://std1.ladio.net:8020/charlie27745*Honjo Promote FM HIME", // Receives but no sound
//"https://stream5.rcast.net/70945*Sound Up Station NFRS", // Receives but no sound
//"https://radio.garden/api/ara/content/listen/ofMcMOvq/channel.mp3*Sound Street Radio", // Receives but no sound
//"http://61.89.201.27:8000/radikishi.mp3*Radio Kishiwada FM 79.7", // Receives but no sound
//"http://onair.fm-tsuyama.jp:1080/fmtsuyama_live.ogg*FM TUYAMA 78.0MHz", // Receives but no sound
//"https://s3.radio.co/sc8d895604/listen*AshiyaRadio*ASIYA Radio", // Receives but no sound
//"https://cc6.streammaximum.com/proxy/radiomegamix/stream*Radio Mega Mix Japan", // Receives but no sound
//"https://www.radio-uk.co.uk/ae/groov-smooth-jazz*smooth-jazz_UK Online Radio Stations", // Receives but no sound
//"http://ice1.somafm.com/illstreet-128-mp3*SomaFM/Illinois Street Lounge", // Receives but no sound
//"http://relax.stream.publicradio.org/relax.mp3*Your Classical - Relax", // Receives but no sound
//"http://ice1.somafm.com/secretagent-128-mp3*SomaFM/Secret Agent", // Receives but no sound
//"http://ice1.somafm.com/seventies-128-mp3*SomaFM/Left Coast 70s", // Receives but no sound
//"http://ice1.somafm.com/bootliquor-128-mp3*SomaFM/Boot Liquor", // Receives but no sound
//"https://somafm.com/indiepop.pls*SomaFM/Indie Pop Rocks!", // Receives but no sound
//"http://us5.internet-radio.com:8201/stream?type=http&nocache=148896*Keith Jarrett-Over The Rainbow", // Receives but no sound
//"http://us2.internet-radio.com:8046/stream?type=http&nocache=87360/*Matt Johnson Radio", // Receives but no sound
//"http://us2.internet-radio.com:8443/listen.pls&t=.m3u*MEGATON CAFE RADIO", // Receives but no sound  MEGATON CAFE RADIO ***
//"http://us2.internet-radio.com:8443/stream?type=http&nocache=84274*RADIO ESTILO LEBLON", // Receives but no sound
//"http://us2.internet-radio.com:8443/stream?type=http&nocache=84424stream?type=http&nocache=84414*MEGATON CAFE RADIO", // Receives but no sound ***
//"http://us2.internet-radio.com:8046/stream?type=http&nocache=87328*us2.internet-radio", // Receives but no sound
//"http://s1.viastreaming.net:8000/;?type=http&nocache=1262945*Smooth Choice", // Receives but no sound
//"http://live.antenne.at/as*Antenne Steiermark", // Receives but no sound
//"http://funkhaus-ingolstadt.stream24.net/radio-in.mp3*funkhaus-ingolstadt.stream24", // Receives but no sound
//"http://108.61.154.147:6978/stream?type=http&nocache=4853/*The Nemesis Radio", // Receives but no sound
//"http://us3.internet-radio.com:8232/stream?type=http&nocache=128897*Radio Cherwell - Hospital Radio in Oxford", // Receives but no sound
//"http://uk5.internet-radio.com:8237/stream?type=http&nocache=739*Stoke Mandeville Hospital Radio", // Receives but no sound
//"http://uk7.internet-radio.com:8040/stream?type=http&nocache=16709*Ava Max - Sweet But Psycho", // Receives but no sound
//"http://sc6.radiocaroline.net:10558/;?type=http&nocache=9769*Radio Caroline Flashback", // Receives but no sound
//"http://listen.181fm.com/181-oldschool_128k.mp3*181 F M Old School", // Receives but no sound
//"http://listen.181fm.com/181-90sdance_128k.mp3*181 F M Nineties Dance", // Receives but no sound
//"http://listen.181fm.com/181-classical_128k.mp3*181 F M Classical", // Receives but no sound
//"http://streamer.radio.co/s06b196587/listen*KPop Way Radio", // Receives but no sound
//"http://media-ice.musicradio.com:80/ClassicFMMP3*Classic FM", // Receives but no sound
//"http://media-ice.musicradio.com:80/ClassicFMMP3*media-ice.musicradio", // Receives but no sound
//"http://91.211.56.218:8080/piramida/nazarovo*Radio Piramida FM", // Receives but no sound
//"http://live.coolradio.rs/cool128*COOL radio | Serbia", // Receives but no sound
//"http://airspectrum.cdnstream1.com:8000/1261_192*Magic Oldies Florida", // Receives but no sound
//"http://rockthecradle.stream.publicradio.org/radioheartland.mp3*Radio Heartland - MPR", // Receives but no sound
//"http://uk1.internet-radio.com:8355/stream?type=http&nocache=14021*The Zone - Dublin", // Receives but no sound
//"http://us2.internet-radio.com:8046/stream?type=http&nocache=87360/*Matt Johnson Radio", // Receives but no sound
//"http://uk5.internet-radio.com:8237/stream?type=http&nocache=739*Stoke Mandeville Hospital Radio", // Receives but no sound

// 58 : Long URL
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_one/bbc_radio_one.isml/bbc_radio_one-audio%3d96000.norewind.m3u8*BBC Radio 1", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_1xtra/bbc_1xtra.isml/bbc_1xtra-audio%3d96000.norewind.m3u8*BBC Radio 1Xtra", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_one_dance/bbc_radio_one_dance.isml/bbc_radio_one_dance-audio%3d96000.norewind.m3u8*BBC Radio 1Dance '94", // Receives but no sound
//"http://as-hls-uk-live.akamaized.net/pool_900/live/uk/bbc_radio_one_anthems/bbc_radio_one_anthems.isml/bbc_radio_one_anthems-audio%3d96000.norewind.m3u8*BBC Radio 1 Anthems (UK Only)", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_two/bbc_radio_two.isml/bbc_radio_two-audio%3d96000.norewind.m3u8*BBC Radio 2", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_three/bbc_radio_three.isml/bbc_radio_three-audio%3d96000.norewind.m3u8*BBC Radio 3", // Receives but no sound
//"http://as-hls-uk-live.akamaized.net/pool_900/live/uk/bbc_radio_three_unwind/bbc_radio_three_unwind.isml/bbc_radio_three_unwind-audio%3d320000.norewind.m3u8*BBC Radio 3 Unwind (UK Only)", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_fourfm/bbc_radio_fourfm.isml/bbc_radio_fourfm-audio%3d96000.norewind.m3u8*BBC Radio 4", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_four_extra/bbc_radio_four_extra.isml/bbc_radio_four_extra-audio%3d96000.norewind.m3u8*BBC Radio 4 Extra", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_five_live/bbc_radio_five_live.isml/bbc_radio_five_live-audio%3d96000.norewind.m3u8*BBC Radio 5 live", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_6music/bbc_6music.isml/bbc_6music-audio%3d96000.norewind.m3u8*BBC Radio 6 Music", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_asian_network/bbc_asian_network.isml/bbc_asian_network-audio%3d96000.norewind.m3u8*BBC Radio Asian Network", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_essex/bbc_radio_essex.isml/bbc_radio_essex-audio%3d96000.norewind.m3u8*BBC BBC Essex", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_hereford_worcester/bbc_radio_hereford_worcester.isml/bbc_radio_hereford_worcester-audio%3d96000.norewind.m3u8*BBC BBC Hereford Worcester", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_berkshire/bbc_radio_berkshire.isml/bbc_radio_berkshire-audio%3d96000.norewind.m3u8*BBC Radio Berkshire", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_bristol/bbc_radio_bristol.isml/bbc_radio_bristol-audio%3d96000.norewind.m3u8*BBC Radio Bristol", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_cambridge/bbc_radio_cambridge.isml/bbc_radio_cambridge-audio%3d96000.norewind.m3u8*BBC Radio Cambridge", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_cornwall/bbc_radio_cornwall.isml/bbc_radio_cornwall-audio%3d96000.norewind.m3u8*BBC Radio Cornwall", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_cumbria/bbc_radio_cumbria.isml/bbc_radio_cumbria-audio%3d96000.norewind.m3u8*BBC Radio Cumbria", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_cymru/bbc_radio_cymru.isml/bbc_radio_cymru-audio%3d96000.norewind.m3u8*BBC Radio Cymru", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_cymru_2/bbc_radio_cymru_2.isml/bbc_radio_cymru_2-audio%3d96000.norewind.m3u8*BBC Radio Cymru 2", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_devon/bbc_radio_devon.isml/bbc_radio_devon-audio%3d96000.norewind.m3u8*BBC Radio Devon", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_foyle/bbc_radio_foyle.isml/bbc_radio_foyle-audio%3d96000.norewind.m3u8*BBC Radio Foyle", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_gloucestershire/bbc_radio_gloucestershire.isml/bbc_radio_gloucestershire-audio%3d96000.norewind.m3u8*BBC Radio Gloucestershire",
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_guernsey/bbc_radio_guernsey.isml/bbc_radio_guernsey-audio%3d96000.norewind.m3u8*BBC Radio Guernsey", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_humberside/bbc_radio_humberside.isml/bbc_radio_humberside-audio%3d96000.norewind.m3u8*BBC Radio Humberside", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_jersey/bbc_radio_jersey.isml/bbc_radio_jersey-audio%3d96000.norewind.m3u8*BBC Radio Jersey", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_kent/bbc_radio_kent.isml/bbc_radio_kent-audio%3d96000.norewind.m3u8*BBC Radio Kent", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_lancashire/bbc_radio_lancashire.isml/bbc_radio_lancashire-audio%3d96000.norewind.m3u8*BBC Radio Lancashire", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_leeds/bbc_radio_leeds.isml/bbc_radio_leeds-audio%3d96000.norewind.m3u8*BBC Radio Leeds", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_leicester/bbc_radio_leicester.isml/bbc_radio_leicester-audio%3d96000.norewind.m3u8*BBC Radio Leicester", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_lincolnshire/bbc_radio_lincolnshire.isml/bbc_radio_lincolnshire-audio%3d96000.norewind.m3u8*BBC Radio Lincolnshire", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_london/bbc_london.isml/bbc_london-audio%3d96000.norewind.m3u8*BBC Radio London", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_manchester/bbc_radio_manchester.isml/bbc_radio_manchester-audio%3d96000.norewind.m3u8*BBC Radio Manchester", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_merseyside/bbc_radio_merseyside.isml/bbc_radio_merseyside-audio%3d96000.norewind.m3u8*BBC Radio Merseyside", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_nan_gaidheal/bbc_radio_nan_gaidheal.isml/bbc_radio_nan_gaidheal-audio%3d96000.norewind.m3u8*BBC Radio nan Gaidheal", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_newcastle/bbc_radio_newcastle.isml/bbc_radio_newcastle-audio%3d96000.norewind.m3u8*BBC Radio Newcastle", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_norfolk/bbc_radio_norfolk.isml/bbc_radio_norfolk-audio%3d96000.norewind.m3u8*BBC Radio Norfolk", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_northampton/bbc_radio_northampton.isml/bbc_radio_northampton-audio%3d96000.norewind.m3u8*BBC Radio northampton", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_nottingham/bbc_radio_nottingham.isml/bbc_radio_nottingham-audio%3d96000.norewind.m3u8*BBC Radio Nottingham", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_orkney/bbc_radio_orkney.isml/bbc_radio_orkney-audio%3d96000.norewind.m3u8*BBC Radio Orkney", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_oxford/bbc_radio_oxford.isml/bbc_radio_oxford-audio%3d96000.norewind.m3u8*BBC Radio Oxford", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_scotland_fm/bbc_radio_scotland_fm.isml/bbc_radio_scotland_fm-audio%3d96000.norewind.m3u8*BBC Radio Scotland FM", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_scotland_mw/bbc_radio_scotland_mw.isml/bbc_radio_scotland_mw-audio%3d96000.norewind.m3u8*BBC Radio Scotland MW", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_sheffield/bbc_radio_sheffield.isml/bbc_radio_sheffield-audio%3d96000.norewind.m3u8*BBC Radio Sheffield", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_shropshire/bbc_radio_shropshire.isml/bbc_radio_shropshire-audio%3d96000.norewind.m3u8*BBC Radio Shropshire", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_solent/bbc_radio_solent.isml/bbc_radio_solent-audio%3d96000.norewind.m3u8*BBC Radio Solent", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_solent_west_dorset/bbc_radio_solent_west_dorset.isml/bbc_radio_solent_west_dorset-audio%3d96000.norewind.m3u8*BBC Radio Solent West Dorset", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_somerset_sound/bbc_radio_somerset_sound.isml/bbc_radio_somerset_sound-audio%3d96000.norewind.m3u8*BBC Radio Somerset Sound", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_stoke/bbc_radio_stoke.isml/bbc_radio_stoke-audio%3d96000.norewind.m3u8*BBC Radio Stoke", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_suffolk/bbc_radio_suffolk.isml/bbc_radio_suffolk-audio%3d96000.norewind.m3u8*BBC Radio Suffolk", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_surrey/bbc_radio_surrey.isml/bbc_radio_surrey-audio%3d96000.norewind.m3u8*BBC Radio Surrey", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_sussex/bbc_radio_sussex.isml/bbc_radio_sussex-audio%3d96000.norewind.m3u8*BBC Radio Sussex", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_tees/bbc_tees.isml/bbc_tees-audio%3d96000.norewind.m3u8*BBC Radio Tees", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_ulster/bbc_radio_ulster.isml/bbc_radio_ulster-audio%3d96000.norewind.m3u8*BBC Radio Ulster", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_wales_fm/bbc_radio_wales_fm.isml/bbc_radio_wales_fm-audio%3d96000.norewind.m3u8*BBC Radio Wales", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_radio_wiltshire/bbc_radio_wiltshire.isml/bbc_radio_wiltshire-audio%3d96000.norewind.m3u8*BBC Radio Wiltshire", // Receives but no sound
//"http://as-hls-ww-live.akamaized.net/pool_900/live/ww/bbc_three_counties_radio/bbc_three_counties_radio.isml/bbc_three_counties_radio-audio%3d96000.norewind.m3u8*BBC Three Counties Radio", // Receives but no sound

  "http://listen.181fm.com/181-uktop40_128k.mp3*181 F M Top 40" // OK

};
//========================================================================
